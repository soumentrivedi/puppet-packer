puppet-packer
=============

Puppet module to install Packer (packer.io)
